package com.example.hw3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {


    private Object MainActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button A = findViewById(R.id.button);
        final EditText B = findViewById(R.id.editTextTextPersonName);
        final EditText C = findViewById(R.id.editTextTextPersonName2);
        final EditText D = findViewById(R.id.editTextTextPersonName3);
        final EditText E = findViewById(R.id.editTextTextPersonName4);
        final EditText F = findViewById(R.id.editTextTextPersonName5);



        A.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent Z = new Intent(MainActivity.this , MainActivity2 . class);
                Z.putExtra("name", B.getText().toString());
                Z.putExtra("name1", C.getText().toString());
                Z.putExtra("name2", D.getText().toString());
                Z.putExtra("name3", E.getText().toString());
                Z.putExtra("name4",F .getText().toString());

                startActivity(Z);

            }
        });




    }
}
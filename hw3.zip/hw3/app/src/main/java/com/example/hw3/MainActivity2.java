package com.example.hw3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

       TextView name = findViewById(R.id.textView10);
        TextView name3 = findViewById(R.id.textView9);
        TextView name4 = findViewById(R.id.textView11);
        TextView name5 = findViewById(R.id.textView14);
        TextView name6 = findViewById(R.id.textView16);


        Bundle name1 = getIntent().getExtras();

        String name2 =name1.getString("name");
        String nameA =name1.getString("name1");
        String nameB =name1.getString("name2");
        String nameC =name1.getString("name3");
        String nameD =name1.getString("name4");

        name.setText(name2);
        name3.setText(nameA);
        name4.setText(nameB);
        name5.setText(nameC);
        name6.setText(nameD);



    }
}